package com.readstep.app

import android.os.Bundle
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.util.Locale

private data class Lesson(val title: String, val description: String)

class MainActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) tts?.language = Locale.US
        }
        setContent { ReadStepApp() }
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }

    @Composable
    private fun ReadStepApp() {
        var selected by remember { mutableIntStateOf(0) }
        val lessons = listOf(
            Lesson("Basic Words", "Read simple everyday words."),
            Lesson("Short Sentences", "Practice clear, short sentences."),
            Lesson("Paragraph Reading", "Build confidence with short passages.")
        )

        MaterialTheme {
            Scaffold(
                bottomBar = {
                    NavigationBar {
                        listOf("Home", "Learn", "Assistant", "Progress").forEachIndexed { i, label ->
                            NavigationBarItem(
                                selected = selected == i,
                                onClick = { selected = i },
                                icon = {},
                                label = { Text(label) }
                            )
                        }
                    }
                }
            ) { padding ->
                when (selected) {
                    0 -> HomeScreen(padding)
                    1 -> LearnScreen(padding, lessons)
                    2 -> AssistantScreen(padding)
                    else -> ProgressScreen(padding)
                }
            }
        }
    }

    @Composable
    private fun HomeScreen(padding: PaddingValues) {
        Column(Modifier.padding(padding).padding(20.dp)) {
            Text("Good morning!", style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(8.dp))
            Text("ReadStep", style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(20.dp))
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(20.dp)) {
                    Text("Your Reading Level", style = MaterialTheme.typography.labelLarge)
                    Text("LEVEL 1", style = MaterialTheme.typography.headlineSmall)
                    Spacer(Modifier.height(12.dp))
                    LinearProgressIndicator(
                        progress = { 0.25f },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
            Spacer(Modifier.height(16.dp))
            Text("Today's Practice", style = MaterialTheme.typography.titleLarge)
            Text("10 words • 5 sentences • 1 paragraph")
        }
    }

    @Composable
    private fun LearnScreen(padding: PaddingValues, lessons: List<Lesson>) {
        LazyColumn(Modifier.padding(padding).padding(16.dp)) {
            item { Text("Learn to Read", style = MaterialTheme.typography.headlineMedium) }
            item { Spacer(Modifier.height(12.dp)) }
            items(lessons) { lesson ->
                Card(Modifier.fillMaxWidth().padding(bottom = 12.dp)) {
                    Column(Modifier.padding(18.dp)) {
                        Text(lesson.title, style = MaterialTheme.typography.titleLarge)
                        Text(lesson.description)
                        Spacer(Modifier.height(10.dp))
                        Button(onClick = {}) { Text("Start") }
                    }
                }
            }
        }
    }

    @Composable
    private fun AssistantScreen(padding: PaddingValues) {
        var word by remember { mutableStateOf("") }
        Column(Modifier.padding(padding).padding(20.dp)) {
            Text("Reading Assistant", style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(12.dp))
            Text("Type a difficult word to hear its pronunciation.")
            Spacer(Modifier.height(16.dp))
            OutlinedTextField(
                value = word,
                onValueChange = { word = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Type a word") },
                singleLine = true
            )
            Spacer(Modifier.height(12.dp))
            Button(
                onClick = {
                    if (word.isNotBlank()) {
                        tts?.speak(word, TextToSpeech.QUEUE_FLUSH, null, "readstep_word")
                    }
                }
            ) { Text("🔊 Listen") }
            Spacer(Modifier.height(12.dp))
            if (word.isNotBlank()) Text("Word: $word")
        }
    }

    @Composable
    private fun ProgressScreen(padding: PaddingValues) {
        Column(Modifier.padding(padding).padding(20.dp)) {
            Text("Your Progress", style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(20.dp))
            Text("Reading Level: 1")
            Text("Lessons Completed: 0")
            Text("Words Practiced: 0")
            Text("Current Streak: 0 days")
            Spacer(Modifier.height(16.dp))
            LinearProgressIndicator(
                progress = { 0.25f },
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}
